package com.example.minorproject.repositories;

import com.example.minorproject.models.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AdminRespository extends JpaRepository<Admin,Integer> {

}
