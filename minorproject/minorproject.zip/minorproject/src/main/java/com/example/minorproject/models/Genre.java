package com.example.minorproject.models;

public enum Genre {

    FICTIONAL, // 0
    NON_FICTIONAL, // 1

    BIOLOGY, // 2
    HISTORY, // 3

    GEOGRAPHY, // 4

    MATHEMATICS, // 5

    LITERATURE, // 6

    PROGRAMMING  // 7

}