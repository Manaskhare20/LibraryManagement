package com.example.minorproject.models;
public enum TransactionStatus {

    PENDING,
    SUCCESS,
    FAILURE
}