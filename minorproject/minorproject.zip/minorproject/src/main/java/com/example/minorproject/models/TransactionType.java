package com.example.minorproject.models;
public enum TransactionType {

    ISSUE,
    RETURN
}