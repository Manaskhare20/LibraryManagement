package com.example.minorproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinorprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
